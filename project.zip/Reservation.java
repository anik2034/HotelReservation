import java.time.LocalDate;
import java.util.ArrayList;

public class Reservation {


    private Room room;
    private LocalDate checkIn;
    private LocalDate checkOut;
    private User user;
    private ArrayList<Reservation> allReservations = new ArrayList<>();



    Reservation(Room room, LocalDate checkIn, LocalDate checkOut, User user){
        this.room=room.clone();
        this.checkIn = checkIn;
        this.checkOut=checkOut;
        this.user= new User(user);


    }












}
