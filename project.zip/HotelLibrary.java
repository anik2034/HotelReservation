

public class HotelLibrary {


    public static Hotel[] getAllHotels(){
        Hotel[] allHotels =new Hotel[5];
        Room h1r1= new Room(10000,
                20,
                45000,
                60000,
                "Single",
                1,
                true,
                false,
                5,
                1);
        Room h1r2= new Room(10000,
                20,
                55000,
                70000,
                "Duo",
                2,
                true,
                false,
                5,
                2);
        Room h1r3= new Room(10000,
                20,
                55000,
                70000,
                "Duo",
                2,
                false,
                true,
                5,
                2);
        Room h1r4= new Room(10000,
                20,
                70000,
                100000,
                "Quad",
                4,
                false,
                true,
                5,
                3);
        Room[] h1Rooms ={h1r1,h1r2,h1r3,h1r4};




        allHotels[0] = new Hotel(5,"Paris Hotel Armenia","Amiryan Street 4/6, Yerevan",true,true,true,h1Rooms);

        Room h2r1= new Room(9000,
                15,
                39000,
                55000,
                "ONE PERSON SUIT",
                1,
                true,
                false,
                5,
                1);
        Room h2r2= new Room(9000,
                15,
                39000,
                55000,
                "ONE PERSON SUIT LUX",
                1,
                false,
                true,
                5,
                1);
        Room h2r3= new Room(9000,
                15,
                45000,
                65000,
                "Double Standard",
                2,
                true,
                false,
                5,
                2);
        Room h2r4= new Room(9000,
                15,
                45000,
                65000,
                "Double Standard+",
                2,
                false,
                true,
                5,
                2);
        Room h2r5= new Room(9000,
                15,
                65000,
                80000,
                "Basic Triple",
                3,
                false,
                true,
                5,
                3);
        Room[] h2Rooms = {h2r1,h2r2,h2r3,h2r4,h2r5};



        allHotels[1]= new Hotel(4,"Best Western Plus Congress Hotel Yerevan","Italy Street 1, Yerevan",true,true,true,h2Rooms);

        return allHotels;
    }



}
