public class User {

    //info about user
    private String firstName;
    private String lastName;
    private String phoneNumber;


    User(String firstName, String lastName, String phoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
    }
    User(User u){
        this.firstName=u.firstName;
        this.lastName=u.lastName;
        this.phoneNumber=u.phoneNumber;

    }

    public String getFirstName() {
        return firstName;
    }



    public String getLastName() {
        return lastName;
    }



    public String getPhoneNumber() {
        return phoneNumber;
    }
















}
